/**
 * 日历函数
 *
 * @author inare2.cn@gmail.com
 * @version 1.0 2009-12-24
 */
 

var Calendar = new (function ()
{
	this.isIE = (new RegExp('internet explorer', 'gi')).test(navigator.appName);
	
	this.$ = function (id)
	{
		return (typeof id === "string") ? document.getElementById(id) : id;
	};

	this.cte = function (e)
	{
		return this.DOM.contentWindow.document.createElement(e);
	};

	this.ctt = function (e)
	{
		return this.DOM.contentWindow.document.createTextNode(e);
	};

	this.setCss = function (ele, style)
	{
		for (p in style)
		{
			ele.style[p] = style[p];
		}
	};

	this.setAttrs = function (e, attrs)
	{
		for (p in attrs)
		{
			e.setAttribute(p, attrs[p]);
		}
	};
	
	this.ebd = function (func, obj) {
		var arg = arguments, s_arg, a_arg=[];
		for (var i=1; i<arg.length; i++) {
			a_arg.push('arg['+i+']');
		}
		s_arg = a_arg.join(', ');
		
		var lambda = function(evt){
			arg[0] = evt;
			
			//这里有个问题：会将this指针指向函数自己
			//func.apply(func, arg);
		
			eval('func(evt, '+s_arg+')');
		};
		
		return lambda;
	};

	this.edd = function (ele, type, func){
		if (ele.addEventListener) {
			ele.addEventListener(type, func, false);
		} else {
			ele.attachEvent('on'+type, func);
		}
	};

	this.erm = function (ele, type, func){
		if (ele.removeEventListener) {
			ele.removeEventListener(type, func, false);
		} else {
			ele.detachEvent('on'+type, func);
		}
	};
	
	//返回元素
	this.ele;
	
	//日历类型[0 没有时分秒][1 有时分秒]
	this.type;
	
	//日历DOM
	this.DOM;
	
	//保存注册在document上的事件
	this.evt;
	
	//时input
	this.hours;
	//分input
	this.minutes;
	//秒input
	this.seconds;
	
	//样式
	this.iframe_style = 'body{margin:0;padding:5;border:1px solid #ccc;background:#fff;line-height:1.5em;} body, input{font-size:14px;}\n';
	this.iframe_style += 'a{cursor:pointer;}\n';
	this.iframe_style += 'a:hover{color:red;}\n';
	
	this.iframe_style += '.top{position:relative;width:100%;border:1px solid #ccc;text-align:center;}';
	this.iframe_style += '.previous, .next{position:absolute;padding:0 5px;}\n';
	this.iframe_style += '.previous{left:5px}\n';
	this.iframe_style += '.next{right:5px;}\n';
	
	this.iframe_style += 'table{margin:5px 0; width:100%;border:1px solid #ccc;border-collapse:collapse;}\n';
	this.iframe_style += 'td{border:1px solid #ccc; text-align:center;}\n';
	this.iframe_style += '.hover{background:#ccc;}\n';
	
	this.iframe_style += '.foot{position:relative;width:100%;}\n';
	this.iframe_style += '.foot .input{}\n';
	this.iframe_style += '.foot input{width:22px;}\n';
	this.iframe_style += '.now, .close{position:absolute;top:0;padding:0 5px;border:1px solid #ccc;}\n';
	this.iframe_style += '.now{right:55px;}\n';
	this.iframe_style += '.close{right:0;}\n';
	
	/**
	 * 将字符串解析成正确的时间函数
	 */
	this.strtotime = function ( str )
	{
		var date = new Date();
		
		if ( typeof str == "string" )
		{
			var aTime = str.split(/\/|,|\s|-|\:/);
			
			if ( aTime.length > 2 )
			{
				date.setFullYear(aTime[0]);
				date.setMonth(aTime[1]);
				date.setDate(aTime[2]);
			}
			
			if ( aTime.length > 5 )
			{
				date.setHours(aTime[3]);
				date.setMinutes(aTime[4]);
				date.setSeconds(aTime[5]);
			}
		}
		
		return date;
	}
	
	/**
	 * 显示日历
	 *
	 * @param Event evt Event对象（以FF,IE兼容）
	 * @param HTMLInputElement ele 最后选择时间输出至此
	 * @param sting type ['date', 'datetime'] 输出是否带有时间
	 * @param Date date | string "1998,12,31 24:30:59" 默认时间
	 */
	this.show = function(evt, ele, type, strtime)
	{
		var event = window.event ? window.event : evt;
		
		this.ele = this.$(ele);
		this.type = (type == 'datetime') ? 1 : 0;
		
		//清缓存
		this.close();
		
		this.DOM = document.createElement('iframe');
		
		this.setAttrs(this.DOM, {
			scrolling : 'no'
		});
		
		this.setCss(this.DOM, {
			position : 'absolute',
			top : (event.clientY + 15) + 'px',
			left : (event.clientX + 15) + 'px',
			width : '220px',
			border : 'none'
		});
		
		document.body.appendChild(this.DOM);

		this.DOM.contentWindow.document.open();
		this.DOM.contentWindow.document.writeln('<style>' + this.iframe_style + '</style>');
		this.DOM.contentWindow.document.close();
		
		this.date( this.strtotime(strtime) );
		
		var oThis = this;
		this.evt = function()
		{
			oThis.close();
		};
		
		/*
		 * 延时,以保证新的日历不会因为用户点击"显示日历"时产生click事件而直接删除
		 */
		setTimeout(function()
		{
			oThis.edd(document, 'click', oThis.evt);
		}, 10);
	};
	
	//关闭日历
	this.close = function()
	{
		if ( this.DOM )
		{
			document.body.removeChild(this.DOM);
			
			this.DOM = null;
			
			//关闭时删除事件
			this.erm(document, 'click', this.evt);
		}
	};
	
	/**
	 * 显示/刷新日历内容
	 *
	 * @param Date date
	 */
	this.date = function(date) {		
		
		var body = this.DOM.contentWindow.document.body;
		
		while ( body.hasChildNodes() )
		{
			body.removeChild(body.firstChild);
		}
		
		var ele_h_dom = this.ele_h(date);
		var ele_b_dom = this.ele_b(date);
		var ele_f_dom = this.ele_f(date);
		
		body.appendChild(ele_h_dom);
		body.appendChild(ele_b_dom);
		body.appendChild(ele_f_dom);
		
		this.setCss(this.DOM, {
			height : ele_h_dom.clientHeight + ele_b_dom.clientHeight + ele_f_dom.clientHeight + 25 + 'px'
		});
	};
	
	//产生头部分
	this.ele_h = function(date) {
		var doc = this.cte('div');
		doc.className = 'top';
		
		var year = date.getFullYear();
		var month = date.getMonth();
		
		var previous = this.cte('a');
		previous.className = 'previous';
		previous.title = '上个月';
		
		previous.appendChild(this.ctt('<'));
		
		this.edd(previous, "click", this.ebd(function(evt, oThis, date){
				var date = new Date(date.toUTCString());
				date.setMonth(date.getMonth()-1);
				
				oThis.date(date);
			}, this, date));
		
		doc.appendChild(previous);
		
		var select_year = this.cte('select');
		for (var i=5, opt; i>-10; i--) {
			opt = this.cte('option');
			
			opt.value = year + i;
			opt.appendChild(this.ctt(year + i));
			if (year + i == year) {
				opt.selected = 'selected';
			}
			
			select_year.appendChild(opt);
		}
		
		this.edd(select_year, 'change', this.ebd(function(evt, oThis, date, ele) {
				var date = new Date(date.toUTCString());
				date.setFullYear(ele.value);
				
				oThis.date(date);
			}, this, date, select_year));
		doc.appendChild(select_year);
		doc.appendChild(this.ctt('年'));
		
		var select_month = this.cte('select');
		
		for (var i=0; i<12; i++) {
			opt = this.cte('option');

			opt.value = i;
			opt.appendChild(this.ctt(i+1));
			if (i == month) {
				opt.selected = 'selected';
			}
			
			select_month.appendChild(opt);
		}
		
		this.edd(select_month, 'change', this.ebd(function(evt, oThis, date, ele) {
				var date = new Date(date.toUTCString());
				date.setMonth(ele.value);
				
				oThis.date(date);
			}, this, date, select_month));
			
		doc.appendChild(select_month);
		doc.appendChild(this.ctt('月'));
		
		var next = this.cte('a');
		next.className = 'next';
		next.title = '下个月';
		
		next.appendChild(this.ctt('>'));
		
		this.edd(next, "click", this.ebd(function(evt, oThis, date, month){
				var date = new Date(date.toUTCString());
				date.setMonth(date.getMonth()+1);
				
				oThis.date(date);
			}, this, date, month));
		
		doc.appendChild(next);
		
		return doc;
	};
		
	//产生星期部分
	this.ele_b = function(date) {
		//年月
		var year = date.getFullYear();
		var month = date.getMonth();
		
		//保存日期
		var dates = new Array(28);
		//星期
		var day = date.getDay();
		
		for (var i=0, tmp; i<31; i++) {
			tmp = new Date(date.toUTCString());
			tmp.setFullYear(year);
			tmp.setMonth(month);
			tmp.setDate(i+1);
			
			//当日期超标，Date对象会自动跳至下一月
			if (tmp.getMonth() == month) {
				dates[day+i] = tmp;
			} else {
				break;
			}
		}
		
		//补齐数据
		while (dates.length % 7 != 0) {
			dates.push(null);
		}
		
		var table = this.cte('table');
		var tbody = this.cte('tbody');
		table.appendChild(tbody);
		
		//原始日期
		var today = date.toDateString();
		
		for (var i=0, tr, td, a; i<dates.length; i++) {
			if (i % 7 == 0) {
				tr = this.cte('tr');
				tbody.appendChild(tr);
			}
			
			td = this.cte('td');
			
			if (dates[i]) {
				if (dates[i].toDateString() == today) {
					td.className = 'hover';
				}
				a = this.cte('a');
				a.appendChild(this.ctt(dates[i].getDate()));
				td.appendChild(a);
				
				this.edd(td, "click", this.ebd(function(evt, oThis, date){
						if (oThis.type) {
							date.setHours(oThis.hours.value);
							date.setMinutes(oThis.minute.value);
							date.setSeconds(oThis.seconds.value);
						}
						oThis.format(date)
					}, this, dates[i]));
				this.edd(td, "click", this.ebd(function(evt, oThis){oThis.close()}, this));
			}
			
			tr.appendChild(td);
		}
		
		return table;
	};
	
	//产生尾部
	this.ele_f = function(date)
	{
		var doc = this.cte('div');
		doc.className = 'foot';
		
		var input = this.cte('div');
		input.className = 'input';
			
		if (this.type)
		{
			var attrs = {maxLength : 2,	size : 2};
		
			this.hours = this.cte('input');
			this.setAttrs(this.hours, attrs);
			this.hours.value = date.getHours();
			input.appendChild(this.hours);
		
			input.appendChild(this.ctt(' : '));
		
			this.minute = this.cte('input');
			this.setAttrs(this.minute, attrs);
			this.minute.value = date.getMinutes();
			input.appendChild(this.minute);
		
			input.appendChild(this.ctt(' : '));
		
			this.seconds = this.cte('input');
			this.setAttrs(this.seconds, attrs);
			this.seconds.value = date.getSeconds();
			input.appendChild(this.seconds);
		}
		else
		{
			input.innerHTML = '&nbsp;';
		}
		
		doc.appendChild ( input );
		
		var now = this.cte('a');
		now.title = '插入当前时间';
		now.className = 'now';
		now.appendChild(this.ctt('now'));
		doc.appendChild(now);
		
		this.edd(now, 'click', this.ebd(function(evt, oThis){oThis.format(new Date());}, this));
		this.edd(now, 'click', this.ebd(function(evt, oThis){oThis.close();}, this));
		
		var close = this.cte('a');
		close.title = '关闭';
		close.className = 'close';
		close.appendChild(this.ctt('close'));
		
		this.edd(close, 'click', this.ebd(function(evt, oThis){oThis.close();}, this));
		
		doc.appendChild(close);

		return doc;
	};
	
	//返回时间（字符串值)
	this.format = function(date)
	{
		var sdate = date.getFullYear() + '-' + (date.getMonth()+1) + '-' + date.getDate();
		
		if (this.type)
		{
			this.ele.value = sdate + ' ' + date.toLocaleTimeString();
			//this.ele.value = sdate + ' ' + date.getHours() + ':' + date.getMinutes() + ':' + date.getSeconds();
		}
		else
		{
			this.ele.value = sdate;
		}
	};
	
})();